SECRET_KEY = "\x10\x10\xd0\x90\x03\xa8(eg(\x16\xd6"
JWT_SECRET = "lskdhflGLfgLf656s4d3f54sdf"